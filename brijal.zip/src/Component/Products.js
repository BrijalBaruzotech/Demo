import { useEffect, useState } from "react";
import axios from "axios";
import {Link} from 'react-router-dom';
//import User1  from "./User1";
//import { Routes } from "react-router-dom";
function Products() {
  const [users, setProduct] = useState([]);

  useEffect(() => {
      console.log("Product")
    axios
      .get("https://61eff057732d93001778e6c0.mockapi.io/Users")
      .then((res) => {
        console.log(res);
        setProduct(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <div>
       
       
       <table style= { {border : 5}}>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => {
            return (
              <tr>
                <td className="th">{user.id}</td>
               <td><Link to="/user">{user.name}</Link></td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
export default Products;