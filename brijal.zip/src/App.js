import {
    BrowserRouter,
    Switch,
    Route,
    Link,
    useRouteMatch
  } from "react-router-dom";
  import User1 from './Component/User1'
  import Products from "./Component/Products";
  
  function App() {
    return (
      <BrowserRouter>
        <Products />
        
        <Switch>
         
          <Route path="/user">
            <User1 />
          </Route>
        </Switch>
      </BrowserRouter>
    );
  }
  export default App;